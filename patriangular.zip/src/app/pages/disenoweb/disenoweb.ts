import { Component } from '@angular/core';

@Component({
  selector: 'app-disenoweb',
  imports: [],
  templateUrl: './disenoweb.html',
  styleUrls: ['./disenoweb.css'],
  standalone: true
})
export class DisenoWebComponent{

}
