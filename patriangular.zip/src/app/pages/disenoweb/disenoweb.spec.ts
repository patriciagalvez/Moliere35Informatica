import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Disenoweb } from './disenoweb';

describe('Disenoweb', () => {
  let component: Disenoweb;
  let fixture: ComponentFixture<Disenoweb>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Disenoweb]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Disenoweb);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
